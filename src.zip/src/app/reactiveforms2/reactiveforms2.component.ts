import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { gte } from './gte.validator';

@Component({
  selector: 'app-reactiveforms2',
  templateUrl: './reactiveforms2.component.html',
  styleUrls: ['./reactiveforms2.component.css']
})
export class Reactiveforms2Component implements OnInit {
loginForm;
  constructor() { }

  ngOnInit(): void {
    this.loginForm=new FormGroup({
      email:new FormControl(),
      password:new FormControl(this.passwordValidation),
      num:new FormControl('',[gte])
    })
  }
  passwordValidation(formcontrol){
    if(formcontrol.value.length<8){
      return({"password":true});
    }
  }
onSubmit(data){
  console.log(data.email);
}
}
