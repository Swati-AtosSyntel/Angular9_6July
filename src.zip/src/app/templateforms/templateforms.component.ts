import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-templateforms',
  templateUrl: './templateforms.component.html',
  styleUrls: ['./templateforms.component.css']
})
export class TemplateformsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
onFormSubmit(data){
  alert("Entered Email ID:"+data.emailID);
}
}
