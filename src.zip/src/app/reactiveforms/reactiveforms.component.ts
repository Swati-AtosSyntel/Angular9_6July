import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-reactiveforms',
  templateUrl: './reactiveforms.component.html',
  styleUrls: ['./reactiveforms.component.css']
})
export class ReactiveformsComponent implements OnInit {
formdata;
emailID;
  constructor() { }

  ngOnInit(): void {
    this.formdata=new FormGroup({
      emailid:new FormControl("angularapp2021@gmail.com",[Validators.email]),
      pwd:new FormControl("abcd1234",[this.passwordValidation]),
      address:new FormGroup({
        country:new FormControl(),
        city:new FormControl(),
        pincode:new FormControl(null,[Validators.pattern('^[1-9][0-9]{4}$')])
      })
    });
  }
  onSubmitForm(data){
    this.emailID=data.emailid
  }
passwordValidation(formcontrol){
  if(formcontrol.value.length<8)
  {
    return {"pwd":true};
  }
}
}
