import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  @Input()
  numReceived;
  
  constructor() { }

  ngOnInit(): void {
  }
  @Output()
thanks=new EventEmitter()

sayThanks($event){
  this.thanks.emit("Thank You for sharing number!!!!");
}
}
