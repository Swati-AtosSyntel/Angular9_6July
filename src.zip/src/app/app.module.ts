import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {Routes,RouterModule} from '@angular/router';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { BasicComponent } from './basic/basic.component';
import { GenderPipe } from './gender.pipe';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { EmployeelistComponent } from './employeelist/employeelist.component';
import { HttpclientexampleComponent } from './httpclientexample/httpclientexample.component';
import { PagenotfoundComponent } from './pagenotfound/pagenotfound.component';
import { TemplateformsComponent } from './templateforms/templateforms.component';
import { ReactiveformsComponent } from './reactiveforms/reactiveforms.component';
const appRoutes:Routes=[
{path:"home",component:BasicComponent},
{path:"employee",component:EmployeeComponent},
{path:"employeeList",component:EmployeelistComponent},
{path:"httpclient",component:HttpclientexampleComponent},
{path:"templateforms",component:TemplateformsComponent},
{path:"reactiveforms",component:ReactiveformsComponent},
{path:"",redirectTo:'/home',pathMatch:'full'},
{path:"**",component:PagenotfoundComponent}
]
@NgModule({
  declarations: [
    AppComponent,
    EmployeeComponent,
    BasicComponent,
    GenderPipe,
    ParentComponent,
    ChildComponent,
    EmployeelistComponent,
    HttpclientexampleComponent,
    PagenotfoundComponent,
    TemplateformsComponent,
    ReactiveformsComponent
  ],
  imports: [
    BrowserModule,FormsModule,HttpClientModule,ReactiveFormsModule,RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
