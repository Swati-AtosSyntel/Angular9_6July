import { Component, OnInit } from '@angular/core';
import { IEmployee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employeelist',
  templateUrl: './employeelist.component.html',
  styleUrls: ['./employeelist.component.css'],
  providers:[EmployeeService]
})
export class EmployeelistComponent implements OnInit {
employees:IEmployee[];
  constructor(private _employeeService:EmployeeService) { }

  ngOnInit(): void {
    this.employees=this._employeeService.getEmployees();
  }
  getTotalEmployeesCount(){
    return this.employees.length;
  }
  getMaleEmployeesCount(){
    return this.employees.filter(emp=>emp.gender==1).length;
  }
  getFemaleEmployeesCount(){
    return this.employees.filter(emp=>emp.gender==2).length;
  }

}
