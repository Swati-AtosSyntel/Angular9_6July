import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit {

  num=0;
  thankyouMessage="";
  constructor() { }

  ngOnInit(): void {
  }
SendToChild(){
  this.num++;
}
receiveThanks(event){
  this.thankyouMessage=event;
  console.log(this.thankyouMessage);
}
}
