import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-basic',
  templateUrl: './basic.component.html',
  styleUrls: ['./basic.component.css']
})
export class BasicComponent implements OnInit {
  isSelected=true;
  colors=['Red','Blue','Orange','Green'];
  show=true;
  month=1;
  name={fname:'Yogesh',lname:'Kumar'};
  constructor() { }

  ngOnInit(): void {
  }

}
