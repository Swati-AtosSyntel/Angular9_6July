import { Component, OnInit } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Repository } from './Repository';
@Component({
  selector: 'app-httpclientexample',
  templateUrl: './httpclientexample.component.html',
  styleUrls: ['./httpclientexample.component.css']
})
export class HttpclientexampleComponent implements OnInit {

  username:string="AngularApp";
  baseUrl:string="https://api.github.com/";
  repos:Repository[];
  constructor(public http:HttpClient) { }

  ngOnInit(): void {
    this.getRepository();
  }
public getRepository(){
  return this.http.get<Repository[]>(
    this.baseUrl+'users/'+this.username+'/repos'
  )
  .subscribe(
    (response)=>
    {
      console.log('response received');
      console.log(response);
      this.repos=response;

    },
    (error)=>{
      console.error("Request Failed");
      console.log(error);
    },
    ()=>{
      console.log('Request completed');
    }
  )
}

}
