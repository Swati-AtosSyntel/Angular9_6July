import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-employeecount',
  templateUrl: './employeecount.component.html',
  styleUrls: ['./employeecount.component.css']
})
export class EmployeecountComponent implements OnInit {

  @Input()
  All:number;
  @Input()
  Male:number;
  @Input()
  Female:number;
  constructor() { }

  ngOnInit(): void {
  }

}
